from setuptools import setup

setup(name='fixer-demo',
      packages=['say_hi'],
      version='0.1',
      license='MIT',
      author='amin',
      description='fixer demo say hi')
