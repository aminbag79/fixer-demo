def say_hi():
    print('hi user welcome')
